// TEMPORARY: bypasses ephemeral token security for Day 1 connectivity testing - must
// revert to proper ephemeral tokens before any production use.
const { requireTechnician } = require('./shared/auth');
const { getSecret } = require('./shared/secrets');

exports.handler = async (event) => {
  try {
    await requireTechnician(event);
    const geminiSecretRaw = await getSecret('fieldloop/gemini-api-key');
    let geminiKey;
    try {
      const parsedSecret = JSON.parse(geminiSecretRaw);
      geminiKey = parsedSecret.apiKey || parsedSecret.api_key || parsedSecret.key;
      if (!geminiKey) throw new Error('no recognizable key field in parsed secret');
    } catch {
      geminiKey = geminiSecretRaw;
    }

    // TEMPORARY / DAY 1 TEST ONLY: returning the raw, long-lived Gemini API key
    // directly to the client instead of minting a short-lived ephemeral token via
    // client.authTokens.create(). This is NOT the final production approach - it
    // hands out an unscoped, unexpiring credential to anyone who can read this
    // response (or later extract it from the client). Only acceptable for today's
    // bare connectivity proof; must be reverted to ephemeral tokens before any
    // production use.
    // TODO: TEMPORARY: bypasses ephemeral token security for Day 1 connectivity
    // testing - must revert to proper ephemeral tokens before any production use.
    return { statusCode: 200, headers: { 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ token: geminiKey }) };
  } catch (err) {
    console.error('Gemini token request failed. Full error:', err);
    console.error('Gemini token request failed. Error keys/props:', JSON.stringify(err, Object.getOwnPropertyNames(err)));
    return { statusCode: 400, headers: { 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ error: err.message }) };
  }
};