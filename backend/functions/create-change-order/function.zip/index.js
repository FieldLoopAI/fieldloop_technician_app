const { requireTechnician } = require('./shared/auth');
const { getSupabaseClient } = require('./shared/supabaseClient');
const { getSecret } = require('./shared/secrets');
const twilio = require('twilio');

exports.handler = async (event) => {
  try {
    const technician = await requireTechnician(event);
    const { jobId, description, additionalAmount } = JSON.parse(event.body);
    const supabase = await getSupabaseClient();

    const { data: changeOrder, error: insertErr } = await supabase
      .from('change_orders')
      .insert({
        job_id: jobId,
        technician_id: technician.id,
        description,
        additional_amount: additionalAmount,
        status: 'pending',
      })
      .select().single();
    if (insertErr) throw insertErr;

    // Send approval SMS to the customer
    const { data: job } = await supabase
      .from('jobs').select('*, customers(*)').eq('id', jobId).single();
    const customerPhone = job?.customers?.primary_phone;

    if (customerPhone) {
      const twilioSecretRaw = await getSecret('fieldloop/twilio-credentials');
      const twilioCreds = JSON.parse(twilioSecretRaw);
      const client = twilio(twilioCreds.accountSid, twilioCreds.authToken);

      await client.messages.create({
        body: `Your technician found additional work needed: ${description}. Additional cost: $${additionalAmount}. Reply YES to approve or NO to decline.`,
        from: twilioCreds.fromNumber,
        to: customerPhone,
      });
    }

    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ changeOrder, smsSent: !!customerPhone }),
    };
  } catch (err) {
    return {
      statusCode: err.message.includes('technician') ? 403 : 400,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: err.message }),
    };
  }
};