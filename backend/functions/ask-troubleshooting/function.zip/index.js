const { requireTechnician } = require('./shared/auth');
const { getSecret } = require('./shared/secrets');
const { getSupabaseClient } = require('./shared/supabaseClient');

const KB_SEARCH_URL = 'https://tqb5mpwlpf.execute-api.us-east-1.amazonaws.com/dev/kb/search';

// Maps this app's jobs.trade_category values to the KB's real trade_slug
// values. Only concrete_and_pavers has real content right now (500
// entries) — everything else currently has zero, so mapping them is safe
// but won't return real answers until more KB content is loaded.
function mapToTradeSlug(tradeCategory) {
  if (!tradeCategory) return 'general_contractor';
  const normalized = tradeCategory.toLowerCase().trim();
  const map = {
    'pavement repairing': 'concrete_and_pavers',
    'electrician': 'general_contractor', // no dedicated electrical KB table exists yet
    'plumbing': 'general_contractor',    // no dedicated plumbing KB table exists yet
    'hvac': 'general_contractor',        // no dedicated HVAC KB table exists yet
  };
  return map[normalized] || 'general_contractor';
}

exports.handler = async (event) => {
  try {
    const technician = await requireTechnician(event);
    const { question, jobId } = JSON.parse(event.body);

    let tradeSlug = 'general_contractor';
    if (jobId) {
      const supabase = await getSupabaseClient();
      const { data: job } = await supabase.from('jobs').select('trade_category').eq('id', jobId).single();
      tradeSlug = mapToTradeSlug(job?.trade_category);
    }

    const kbResponse = await fetch(KB_SEARCH_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': event.headers.Authorization || event.headers.authorization,
      },
      body: JSON.stringify({ question, trade_slug: tradeSlug }),
    });
    const kbData = await kbResponse.json();

    // Only trust the KB's answer as final when it's a genuine confident
    // match — NOT "no_match" and NOT "llm_escalation" (which means low-
    // confidence candidates were found but the KB itself deferred).
    const isConfidentKbMatch = kbData.source && kbData.source !== 'no_match' && kbData.source !== 'llm_escalation';

    if (isConfidentKbMatch && kbData.answer) {
      return {
        statusCode: 200,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ answer: kbData.answer, source: 'knowledge_base', verifyLocally: kbData.verify_locally }),
      };
    }

    // No confident KB match — fall back to Groq, optionally passing along
    // the KB's low-confidence candidate fact titles as extra context so
    // Groq's reasoning isn't starting from nothing.
    const groqSecretRaw = await getSecret('fieldloop/groq-api-key');
    let groqKey;
    try {
      const parsedSecret = JSON.parse(groqSecretRaw);
      groqKey = parsedSecret.apiKey || parsedSecret.api_key || parsedSecret.key;
      if (!groqKey) throw new Error('no recognizable key field');
    } catch {
      groqKey = groqSecretRaw;
    }

    const candidateTitles = (kbData.matches || []).map(m => m.fact_title).join(', ');
    const systemPrompt = candidateTitles
      ? `You are a helpful field technician coach. Related topics that may or may not be relevant: ${candidateTitles}. Give a short, practical, spoken-friendly answer.`
      : 'You are a helpful field technician coach. Give short, practical, spoken-friendly answers.';

    const groqResponse = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${groqKey}` },
      body: JSON.stringify({
        model: 'llama-3.1-8b-instant',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: question },
        ],
        max_tokens: 200,
      }),
    });
    const groqData = await groqResponse.json();
    const answer = groqData.choices?.[0]?.message?.content || "Sorry, I couldn't find an answer.";

    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ answer, source: 'groq_fallback' }),
    };
  } catch (err) {
    return {
      statusCode: err.message.includes('technician') ? 403 : 400,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: err.message }),
    };
  }
};