const { requireTechnician } = require('./shared/auth');
const { getSupabaseClient } = require('./shared/supabaseClient');
const { getSecret } = require('./shared/secrets');

exports.handler = async (event) => {
  try {
    await requireTechnician(event);
    const { dictationId } = JSON.parse(event.body);
    const supabase = await getSupabaseClient();

    const { data: dictation, error: fetchErr } = await supabase
      .from('job_dictations').select('*').eq('id', dictationId).single();
    if (fetchErr) throw fetchErr;

    const groqKey = await getSecret('fieldloop/groq-api-key');
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${groqKey}` },
      body: JSON.stringify({
        model: 'llama-3.1-8b-instant',
        messages: [
          { role: 'system', content: 'Extract line items from a technician\'s spoken estimate. Return ONLY valid JSON: {"line_items":[{"description":"...","amount":0.00}],"total_amount":0.00}. Do not invent numbers not present in the text - if unclear, make your best literal reading of what was said.' },
          { role: 'user', content: dictation.transcript },
        ],
      }),
    });
    const groqData = await response.json();
    const parsed = JSON.parse(groqData.choices[0].message.content);

    const { data: estimate, error: insertErr } = await supabase.from('job_estimates').insert({
      job_id: dictation.job_id,
      source_dictation_id: dictationId,
      line_items: parsed.line_items,
      total_amount: parsed.total_amount,
    }).select().single();
    if (insertErr) throw insertErr;

    await supabase.from('job_dictations').update({ status: 'processed' }).eq('id', dictationId);

    return { statusCode: 200, headers: { 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ estimate }) };
  } catch (err) {
    return { statusCode: 400, headers: { 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ error: err.message }) };
  }
};